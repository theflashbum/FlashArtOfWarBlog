Thank you for downloading this source code from my blog FlashArtOfWar.com. Feel free to use this code as an example for your own project.

If you have questions or plan on using this in your own site, please let me know at jesse@flashartofwar.com

Jesse Freeman
http://www.flashartofwar.com